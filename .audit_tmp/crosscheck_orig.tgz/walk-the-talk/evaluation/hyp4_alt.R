# Complementary directional test for Research Question 4.
#
# The primary test in hyp4.R asks whether interaction-aware faithfulness is
# higher than the controlled atomic baseline. This script tests the opposite
# directional alternative on the same paired question-level estimates:
#
#   F_joint(x) - F_atomic(x) < 0.

source("faithfulness_loader.R")

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

datasets <- c("bbq", "medqa", "new_german_credit")
models <- c("gpt-oss:120b", "mistral-medium-3_5")
joint_appendices <- c(bbq = 4L, medqa = 4L, new_german_credit = 3L)
alpha <- 0.05

arguments <- commandArgs(trailingOnly = TRUE)
output_file <- if (length(arguments)) arguments[[1L]] else
  "/Users/jonathan/Documents/Studium/Semester 4/Master's Thesis/data/rq4/lower_faithfulness_test_results.csv"

display_dataset <- function(x) switch(
  x,
  bbq = "BBQ",
  medqa = "MedQA",
  new_german_credit = "New German Credit",
  x
)

display_model <- function(x) switch(
  x,
  "gpt-oss:120b" = "GPT-OSS 120B",
  "mistral-medium-3_5" = "Mistral Medium 3.5",
  x
)

load_atomic_faithfulness_json <- function(dataset, model, appendix) {
  path <- file.path(
    felics_base_path,
    dataset,
    paste0(model, "_", appendix),
    paste0(model, "_faithfulness_results_atomic_ce.json")
  )
  if (!file.exists(path)) stop("File does not exist: ", path)
  fromJSON(path, flatten = TRUE)
}

results <- list()
for (dataset in datasets) {
  appendix <- unname(joint_appendices[[dataset]])
  for (model in models) {
    atomic <- load_atomic_faithfulness_json(dataset, model, appendix)
    joint <- load_faithfulness_json(dataset, model, appendix)

    pairs <- atomic$example_level_faithfulness %>%
      transmute(
        example_idx = as.character(example_idx),
        atomic_faithfulness = faithfulness_beta_mean
      ) %>%
      inner_join(
        joint$example_level_faithfulness %>%
          transmute(
            example_idx = as.character(example_idx),
            joint_faithfulness = faithfulness_beta_mean
          ),
        by = "example_idx"
      ) %>%
      filter(
        is.finite(atomic_faithfulness),
        is.finite(joint_faithfulness)
      ) %>%
      mutate(difference = joint_faithfulness - atomic_faithfulness)

    test <- wilcox.test(
      pairs$difference,
      mu = 0,
      alternative = "less"
    )

    results[[length(results) + 1L]] <- data.frame(
      dataset = display_dataset(dataset),
      model = display_model(model),
      n = nrow(pairs),
      median_difference = median(pairs$difference),
      n_positive = sum(pairs$difference > 0),
      n_negative = sum(pairs$difference < 0),
      n_zero = sum(pairs$difference == 0),
      p = test$p.value,
      supported = test$p.value <= alpha,
      stringsAsFactors = FALSE
    )
  }
}

results <- bind_rows(results)
results$supported <- ifelse(results$supported, "true", "false")
dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
write_csv(results, output_file)

print(results, row.names = FALSE)
cat("\nWrote lower-faithfulness test results to ",
    normalizePath(output_file), "\n", sep = "")
