# Hypothesis 2: atomic FELICS (n_max = 1) versus Matton's metric.
# The deterministic agreement check is primary; fixed-margin TOSTs are
# secondary empirical evidence. Primary results require identical cached model
# outputs or identical random seeds for the two implementations.

source("faithfulness_loader.R")
library(dplyr)
library(readr)
library(TOSTER)

datasets <- c("bbq", "medqa", "new_german_credit")
models <- c("gpt-oss:120b", "mistral-medium-3_5")
appendix <- 1L
tau <- 1e-8
delta_ce <- 0.1
delta_faith <- 0.1
alpha <- 0.05

# The first optional command-line argument selects the thesis RQ2 data
# directory. The default points to the local thesis checkout used for the
# experiments.
arguments <- commandArgs(trailingOnly = TRUE)
output_directory <- if (length(arguments)) arguments[[1L]] else
  "/Users/jonathan/Documents/Studium/Semester 4/Master's Thesis/data/rq2"
dir.create(output_directory, recursive = TRUE, showWarnings = FALSE)

require_columns <- function(data, columns, label) {
  missing <- setdiff(columns, names(data))
  if (length(missing)) stop(label, " is missing: ", paste(missing, collapse = ", "))
}

mean_by_question <- function(data, value_column, output_column, label) {
  require_columns(data, c("example_idx", value_column), label)
  result <- data %>%
    group_by(example_idx) %>%
    summarise(value = if (all(is.na(.data[[value_column]]))) NA_real_ else
      mean(.data[[value_column]], na.rm = TRUE), .groups = "drop")
  names(result)[names(result) == "value"] <- output_column
  result
}

pair_shared_questions <- function(matton, felics, value_name, metric_name) {
  matton_name <- paste0("matton_", value_name)
  felics_name <- paste0("felics_", value_name)
  paired <- inner_join(matton, felics, by = "example_idx") %>%
    filter(is.finite(.data[[matton_name]]), is.finite(.data[[felics_name]])) %>%
    arrange(example_idx)
  if (!nrow(paired)) stop("No finite shared questions for ", metric_name, ".")
  list(
    data = paired,
    missing_in_matton = setdiff(felics$example_idx, matton$example_idx),
    missing_in_felics = setdiff(matton$example_idx, felics$example_idx)
  )
}

agreement_diagnostics <- function(differences) {
  absolute <- abs(differences)
  within <- absolute <= tau
  list(n = length(differences), max_abs_difference = max(absolute),
       mean_abs_difference = mean(absolute),
       proportion_within_tolerance = mean(within), compatible = all(within))
}

run_secondary_tost <- function(differences, margin, name) {
  if (length(differences) < 2L || !is.finite(sd(differences)) || sd(differences) == 0) {
    reason <- if (length(differences) < 2L) "fewer than two paired observations" else
      "the paired differences have zero variance"
    return(list(test = NULL, lower_p = NA_real_, upper_p = NA_real_,
                equivalent = NA, reason = paste(name, "is undefined because", reason)))
  }
  test <- t_TOST(x = differences, mu = 0, eqb = margin, alpha = alpha,
                 hypothesis = "EQU")
  p <- as.numeric(test$TOST$p.value[2:3])
  list(test = test, lower_p = p[1], upper_p = p[2],
       equivalent = all(p < alpha), reason = NULL)
}

print_agreement <- function(label, x) cat(
  label, " deterministic agreement: n=", x$n,
  ", max |difference|=", format(x$max_abs_difference, digits = 6),
  ", mean |difference|=", format(x$mean_abs_difference, digits = 6),
  ", proportion within tau=", format(x$proportion_within_tolerance, digits = 6),
  ", compatible=", x$compatible, "\n", sep = "")

print_tost <- function(label, x) {
  if (is.null(x$test)) cat(label, " secondary TOST: not evaluated (", x$reason, ")\n", sep = "")
  else cat(label, " secondary TOST: lower p=", format(x$lower_p, digits = 6),
           ", upper p=", format(x$upper_p, digits = 6),
           ", equivalent=", x$equivalent, "\n", sep = "")
}

display_dataset <- function(x) switch(
  x,
  bbq = "BBQ",
  medqa = "MedQA",
  new_german_credit = "New German Credit",
  x
)

display_model <- function(x) switch(
  x,
  "gpt-oss:120b" = "GPT-OSS 120B",
  "mistral-medium-3_5" = "Mistral Medium 3.5",
  x
)

file_model <- function(x) switch(
  x,
  "gpt-oss:120b" = "gptoss",
  "mistral-medium-3_5" = "mistral",
  x
)

write_thesis_csv <- function(data, path) {
  logical_columns <- vapply(data, is.logical, logical(1))
  data[logical_columns] <- lapply(
    data[logical_columns],
    function(column) ifelse(column, "true", "false")
  )
  write_csv(data, path, na = "")
}

run_difference_test <- function(differences, label) {
  differences <- differences[is.finite(differences)]
  if (length(differences) < 2L || !is.finite(sd(differences)) || sd(differences) == 0) {
    reason <- if (length(differences) < 2L) "fewer than two paired observations" else
      "the paired differences have zero variance"
    return(list(n = length(differences), mean_difference = mean(differences),
                statistic = NA_real_, p_value = NA_real_, significant = NA,
                reason = paste(label, "is undefined because", reason)))
  }
  test <- t.test(differences, mu = 0, alternative = "two.sided")
  list(n = length(differences), mean_difference = mean(differences),
       statistic = unname(test$statistic), p_value = test$p.value,
       significant = test$p.value < alpha, reason = NA_character_)
}

run_hypothesis_2_test <- function(matton_ce, felics_ce, matton_faith, felics_faith) {
  matton_faith_table <- matton_faith$example_level_faithfulness
  felics_faith_table <- felics_faith$example_level_faithfulness
  if (is.null(matton_faith_table) || is.null(felics_faith_table))
    stop("Faithfulness JSON lacks example_level_faithfulness.")

  matton_avg_ce <- mean_by_question(matton_ce, "kl_div", "matton_avg_ce", "Matton CE")
  felics_avg_ce <- mean_by_question(felics_ce, "adjusted_shapley_kl_div",
                                    "felics_avg_ce", "FELICS Shapley CE")
  matton_avg_faith <- mean_by_question(matton_faith_table, "faithfulness_beta_mean",
                                       "matton_avg_faith", "Matton faithfulness")
  felics_avg_faith <- mean_by_question(felics_faith_table, "faithfulness_beta_mean",
                                       "felics_avg_faith", "FELICS faithfulness")

  ce_pairing <- pair_shared_questions(matton_avg_ce, felics_avg_ce, "avg_ce", "CE")
  faith_pairing <- pair_shared_questions(matton_avg_faith, felics_avg_faith,
                                         "avg_faith", "faithfulness")

  # Thesis convention: differences are FELICS minus Matton.
  ce_pairs <- ce_pairing$data %>% mutate(
    difference = felics_avg_ce - matton_avg_ce,
    symmetric_relative_difference =
      2 * difference / (felics_avg_ce + matton_avg_ce + tau))
  faith_pairs <- faith_pairing$data %>%
    mutate(difference = felics_avg_faith - matton_avg_faith)

  ce_agreement <- agreement_diagnostics(ce_pairs$difference)
  faith_agreement <- agreement_diagnostics(faith_pairs$difference)
  ce_tost <- run_secondary_tost(ce_pairs$symmetric_relative_difference,
                                delta_ce, "CE TOST")
  faith_tost <- run_secondary_tost(faith_pairs$difference,
                                   delta_faith, "Faithfulness TOST")

  list(primary_compatible = ce_agreement$compatible && faith_agreement$compatible,
       ce_agreement = ce_agreement, faith_agreement = faith_agreement,
       ce_tost = ce_tost, faith_tost = faith_tost,
       ce_pairs = ce_pairs, faith_pairs = faith_pairs,
       coverage = list(ce_missing_in_matton = ce_pairing$missing_in_matton,
                       ce_missing_in_felics = ce_pairing$missing_in_felics,
                       faith_missing_in_matton = faith_pairing$missing_in_matton,
                       faith_missing_in_felics = faith_pairing$missing_in_felics))
}

results_summary <- list()
for (dataset in datasets) for (model in models) {
  cat("\n=============================================\n",
      dataset, " | ", model, " | n_max: ", appendix,
      "\n=============================================\n", sep = "")
  matton_ce <- load_faithfulness_table(dataset, model, appendix, "ce_estimates", "matton")
  felics_ce <- load_faithfulness_table(dataset, model, appendix,
                                       "shapley_ce_estimates", "felics")
  matton_faith <- load_faithfulness_json(dataset, model, appendix, "matton")
  felics_faith <- load_faithfulness_json(dataset, model, appendix, "felics")
  result <- run_hypothesis_2_test(matton_ce, felics_ce, matton_faith, felics_faith)

  faith_plot_data <- result$faith_pairs %>%
    transmute(
      example_idx = as.integer(example_idx),
      matton_faithfulness = matton_avg_faith,
      felics_faithfulness = felics_avg_faith
    ) %>%
    arrange(example_idx)
  write_thesis_csv(
    faith_plot_data,
    file.path(
      output_directory,
      paste0(dataset, "_", file_model(model), ".csv")
    )
  )

  ce_plot_data <- result$ce_pairs %>%
    transmute(
      example_idx = as.integer(example_idx),
      matton_ce = matton_avg_ce,
      felics_ce = felics_avg_ce
    ) %>%
    arrange(example_idx)
  write_thesis_csv(
    ce_plot_data,
    file.path(
      output_directory,
      paste0(dataset, "_", file_model(model), "_ce.csv")
    )
  )

  print_agreement("CE", result$ce_agreement)
  print_agreement("Faithfulness", result$faith_agreement)
  print_tost("CE", result$ce_tost)
  print_tost("Faithfulness", result$faith_tost)
  coverage <- result$coverage
  cat("Shared-question coverage: CE missing in Matton/FELICS=",
      length(coverage$ce_missing_in_matton), "/", length(coverage$ce_missing_in_felics),
      "; faithfulness missing in Matton/FELICS=",
      length(coverage$faith_missing_in_matton), "/",
      length(coverage$faith_missing_in_felics), "\n", sep = "")
  results_summary[[length(results_summary) + 1L]] <-
    list(dataset = dataset, model = model, appendix = appendix, result = result)
}

status <- function(x) if (is.na(x)) "not evaluated" else if (x) "equivalent" else "not equivalent"
cat("\nHypothesis 2 summary\n")
for (entry in results_summary) cat(
  "- Dataset: ", entry$dataset, " | Model: ", entry$model,
  " | n_max: ", entry$appendix,
  " | Primary deterministic compatibility: ", entry$result$primary_compatible,
  " | Secondary CE TOST: ", status(entry$result$ce_tost$equivalent),
  " | Secondary faithfulness TOST: ", status(entry$result$faith_tost$equivalent),
  "\n", sep = "")

hypothesis_results <- lapply(results_summary, function(entry) {
  result <- entry$result
  ce_equivalent <- isTRUE(result$ce_tost$equivalent)
  faith_equivalent <- isTRUE(result$faith_tost$equivalent)
  data.frame(
    dataset = display_dataset(entry$dataset),
    model = display_model(entry$model),
    n = nrow(result$faith_pairs),
    exact = result$primary_compatible,
    p_ce = if (is.null(result$ce_tost$test)) NA_real_ else
      max(result$ce_tost$lower_p, result$ce_tost$upper_p),
    p_faithfulness = if (is.null(result$faith_tost$test)) NA_real_ else
      max(result$faith_tost$lower_p, result$faith_tost$upper_p),
    supported = ce_equivalent && faith_equivalent,
    stringsAsFactors = FALSE
  )
})
hypothesis_results <- do.call(rbind, hypothesis_results)
hypothesis_results$p_ce <- round(hypothesis_results$p_ce, 4)
hypothesis_results$p_faithfulness <- round(
  hypothesis_results$p_faithfulness,
  4
)
write_thesis_csv(
  hypothesis_results,
  file.path(output_directory, "hypothesis_test_results.csv")
)

difference_results <- lapply(results_summary, function(entry) {
  ce <- run_difference_test(
    entry$result$ce_pairs$symmetric_relative_difference,
    "CE difference test"
  )
  faith <- run_difference_test(
    entry$result$faith_pairs$difference,
    "Faithfulness difference test"
  )
  data.frame(
    dataset = display_dataset(entry$dataset),
    model = display_model(entry$model),
    n_ce = ce$n,
    mean_ce_difference = ce$mean_difference,
    t_ce = ce$statistic,
    p_ce = ce$p_value,
    ce_significant = ce$significant,
    n_faithfulness = faith$n,
    mean_faithfulness_difference = faith$mean_difference,
    t_faithfulness = faith$statistic,
    p_faithfulness = faith$p_value,
    faithfulness_significant = faith$significant,
    both_significant = isTRUE(ce$significant) && isTRUE(faith$significant),
    stringsAsFactors = FALSE
  )
})
difference_results <- do.call(rbind, difference_results)
write_thesis_csv(
  difference_results,
  file.path(output_directory, "difference_test_results.csv")
)

cat("\nWrote RQ2 plot and test CSVs to ",
    normalizePath(output_directory), "\n", sep = "")
