# Complementary difference tests for Hypothesis 2.
#
# The primary RQ2 analysis in hyp2.R uses paired t-based TOSTs to test whether
# differences between FELICS (n_max = 1) and Matton's metric fall within the
# prespecified equivalence margins. Failure to establish equivalence does not
# establish a difference. This script therefore applies conventional two-sided
# one-sample t-tests to the same paired-difference vectors, testing H0: mean
# difference = 0 against H1: mean difference != 0.

source("hyp2.R")

alpha_difference <- 0.05

run_difference_test <- function(differences, label) {
  differences <- differences[is.finite(differences)]
  if (length(differences) < 2L || !is.finite(sd(differences)) || sd(differences) == 0) {
    reason <- if (length(differences) < 2L) "fewer than two paired observations" else
      "the paired differences have zero variance"
    return(list(n = length(differences), mean_difference = mean(differences),
                statistic = NA_real_, p_value = NA_real_, significant = NA,
                reason = paste(label, "is undefined because", reason)))
  }

  test <- t.test(differences, mu = 0, alternative = "two.sided")
  list(n = length(differences), mean_difference = mean(differences),
       statistic = unname(test$statistic), p_value = test$p.value,
       significant = test$p.value < alpha_difference, reason = NA_character_)
}

display_dataset <- function(x) switch(x, bbq = "BBQ", medqa = "MedQA", x)
display_model <- function(x) switch(
  x,
  "gpt-oss:120b" = "GPT-OSS 120B",
  "mistral-medium-3_5" = "Mistral Medium 3.5",
  x
)

difference_results <- lapply(results_summary, function(entry) {
  ce <- run_difference_test(
    entry$result$ce_pairs$symmetric_relative_difference,
    "CE difference test"
  )
  faith <- run_difference_test(
    entry$result$faith_pairs$difference,
    "Faithfulness difference test"
  )

  data.frame(
    dataset = display_dataset(entry$dataset),
    model = display_model(entry$model),
    n_ce = ce$n,
    mean_ce_difference = ce$mean_difference,
    t_ce = ce$statistic,
    p_ce = ce$p_value,
    ce_significant = ce$significant,
    n_faithfulness = faith$n,
    mean_faithfulness_difference = faith$mean_difference,
    t_faithfulness = faith$statistic,
    p_faithfulness = faith$p_value,
    faithfulness_significant = faith$significant,
    both_significant = isTRUE(ce$significant) && isTRUE(faith$significant),
    stringsAsFactors = FALSE
  )
})

difference_results <- do.call(rbind, difference_results)
print(difference_results, row.names = FALSE)

arguments <- commandArgs(trailingOnly = TRUE)
output_file <- if (length(arguments)) arguments[[1L]] else "hyp2_difference_test_results.csv"
write.table(difference_results, output_file, sep = ",", row.names = FALSE,
            col.names = TRUE, quote = FALSE, na = "")
cat("\nWrote difference-test results to ", normalizePath(output_file), "\n", sep = "")
