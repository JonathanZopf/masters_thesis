# Faithfulness Results Loader Module
#
# This module provides functions to load faithfulness result tables from both
# FELICS and Matton's original metric.
#
# Dependencies:
#   - readr (for reading CSV files)
#
# Configuration:
#   Modify `felics_base_path` and `matton_base_path` below if your data is in a different location.
#
# Usage:
#   source("faithfulness_loader.R")
#
#   # Load a single table from FELICS
#   atomic_ce <- load_faithfulness_table("medqa", "gpt-oss:120b", 1, "ce_estimates", "felics")
#
#   # Load all FELICS tables for a dataset/model/appendix
#   felics_tables <- load_felics_tables("medqa", "gpt-oss:120b", 1)
#
#   # Load all Matton tables for a dataset/model/appendix
#   matton_tables <- load_matton_tables("medqa", "gpt-oss:120b", 1)
#
# File structure:
#   FELICS: <felics_base_path>/<dataset>/<model>_<appendix>/<model>_<table_type>.csv
#   Matton: <matton_base_path>/<dataset>/<model>_/<model>_<table_type>.csv
#
# Available table types:
#   - FELICS: "adjusted_kl_div", "ce_estimates", "ee_estimates", "shapley_ce_estimates"
#   - Matton: "ce_estimates", "ee_estimates"

library(jsonlite)

# Base paths - modify these if your data is located elsewhere
felics_base_path <- file.path("..", "experiment", "faithfulness_results")
matton_base_path <- "/Users/jonathan/Desktop/WTT-original/Walk-the-Talk-Correlated/experiment/faithfulness_results"

#' Safe CSV loader
#'
#' Loads a CSV file with error checking.
#'
#' @param path Path to the CSV file
#' @return A data frame
load_csv_safe <- function(path) {
  if (!file.exists(path)) {
    stop("File does not exist: ", path)
  }
  
  tryCatch(
    {
      readr::read_csv(
        path,
        show_col_types = FALSE
      )
    },
    error = function(e) {
      stop(
        paste(
          "Could not load:",
          path,
          "\n",
          e$message
        )
      )
    }
  )
}

#' Load a faithfulness results table
#'
#' Loads a single faithfulness results table from either FELICS or Matton's original metric.
#'
#' @param dataset Dataset name (e.g., "medqa")
#' @param model Model name (e.g., "gpt-oss:120b")
#' @param appendix Appendix number (e.g., 1, 4)
#' @param table_type Type of table. For FELICS: "adjusted_kl_div", "ce_estimates",
#'        "ee_estimates", "shapley_ce_estimates". For Matton: "ce_estimates", "ee_estimates".
#' @param source Source of data: "felics" or "matton"
#' @return A data frame
load_faithfulness_table <- function(dataset, model, appendix, table_type, source = c("felics", "matton")) {
  source <- match.arg(source)
  
  # Validate table_type based on source
  felics_types <- c("adjusted_kl_div", "ce_estimates", "ee_estimates", "shapley_ce_estimates")
  matton_types <- c("ce_estimates", "ee_estimates")
  
  if (source == "felics" && !table_type %in% felics_types) {
    stop("Invalid table_type for FELICS. Must be one of: ", paste(felics_types, collapse = ", "))
  }
  if (source == "matton" && !table_type %in% matton_types) {
    stop("Invalid table_type for Matton. Must be one of: ", paste(matton_types, collapse = ", "))
  }
  
  # Get base path
  if (source == "felics") {
    base_path <- felics_base_path
  } else {
    base_path <- matton_base_path
  }
  
  # Matton's original implementation has no n_max setting. Its active result
  # directories therefore end in a bare underscore, whereas FELICS encodes
  # n_max in the directory name.
  folder_name <- if (source == "matton") {
    paste0(model, "_")
  } else {
    paste0(model, "_", appendix)
  }
  folder <- file.path(base_path, dataset, folder_name)
  file_name <- paste0(model, "_", table_type, ".csv")
  full_path <- file.path(folder, file_name)
  
  # Load and return
  load_csv_safe(full_path)
}

#' Load all FELICS tables for a dataset/model/appendix
#'
#' Loads all four FELICS faithfulness result tables for a given dataset, model, and appendix.
#'
#' @param dataset Dataset name
#' @param model Model name
#' @param appendix Appendix number
#' @return A named list of data frames with elements:
#'         adjusted_kl_div, ce_estimates, ee_estimates, shapley_ce_estimates
load_felics_tables <- function(dataset, model, appendix) {
  list(
    adjusted_kl_div = load_faithfulness_table(dataset, model, appendix, "adjusted_kl_div", "felics"),
    ce_estimates = load_faithfulness_table(dataset, model, appendix, "ce_estimates", "felics"),
    ee_estimates = load_faithfulness_table(dataset, model, appendix, "ee_estimates", "felics"),
    shapley_ce_estimates = load_faithfulness_table(dataset, model, appendix, "shapley_ce_estimates", "felics")
  )
}

#' Load all Matton tables for a dataset/model/appendix
#'
#' Loads both Matton faithfulness result tables for a given dataset, model, and appendix.
#'
#' @param dataset Dataset name
#' @param model Model name
#' @param appendix Appendix number
#' @return A named list of data frames with elements: ce_estimates, ee_estimates
load_matton_tables <- function(dataset, model, appendix) {
  list(
    ce_estimates = load_faithfulness_table(dataset, model, appendix, "ce_estimates", "matton"),
    ee_estimates = load_faithfulness_table(dataset, model, appendix, "ee_estimates", "matton")
  )
}

##########################################################
# Helper function to load faithfulness JSON
##########################################################

load_faithfulness_json <- function(dataset, model, appendix, source = c("felics", "matton")) {
  source <- match.arg(source)
  
  if (source == "matton") {
    base_path <- "/Users/jonathan/Desktop/WTT-original/Walk-the-Talk-Correlated/experiment/faithfulness_results"
    file_name <- paste0(model, "_faithfulness_results.json")
  } else {
    base_path <- file.path("..", "experiment", "faithfulness_results")
    file_name <- paste0(model, "_faithfulness_results.json")
  }
  
  folder_name <- if (source == "matton") {
    paste0(model, "_")
  } else {
    paste0(model, "_", appendix)
  }
  folder <- file.path(base_path, dataset, folder_name)
  full_path <- file.path(folder, file_name)
  
  if (!file.exists(full_path)) {
    stop("File does not exist: ", full_path)
  }
  
  fromJSON(full_path, flatten = TRUE)
}
