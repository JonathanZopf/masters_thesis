# Hypothesis 4 Checking Script
# Checks if FELICS with n_max > 1 increases average faithfulness compared to n_max = 1
# Uses the faithfulness_loader module
# Halts execution immediately if any file cannot be loaded

source("faithfulness_loader.R")

library(dplyr)
library(readr)

##########################################################
# Configuration
##########################################################

datasets <- c(
  "bbq",
  "medqa",
  "new_german_credit"
)

models <- c(
  "gpt-oss:120b",
  "mistral-medium-3_5"
)

# For each dataset specify appendices
dataset_appendices <- list(
  medqa = c(1, 4),
  bbq = c(1, 4),
  new_german_credit = c(1,3)
  
)

load_atomic_faithfulness_json <- function(dataset, model, appendix) {
  folder <- file.path(
    felics_base_path,
    dataset,
    paste0(model, "_", appendix)
  )
  full_path <- file.path(
    folder,
    paste0(model, "_faithfulness_results_atomic_ce.json")
  )

  if (!file.exists(full_path)) {
    stop("File does not exist: ", full_path)
  }

  fromJSON(full_path, flatten = TRUE)
}

##########################################################
# Hypothesis test
##########################################################

run_hypothesis_4_test <- function(faith_appendix_1, faith_appendix_n) {
  
  # Extract faithfulness_beta_mean for each example
  faith_1 <- faith_appendix_1$example_level_faithfulness %>%
    select(example_idx, faithfulness_beta_mean)
  
  faith_n <- faith_appendix_n$example_level_faithfulness %>%
    select(example_idx, faithfulness_beta_mean)
  
  # Ensure same examples in both
  common_examples <- intersect(faith_1$example_idx, faith_n$example_idx)
  
  faith_1 <- faith_1 %>% filter(example_idx %in% common_examples)
  faith_n <- faith_n %>% filter(example_idx %in% common_examples)
  
  # Order by example_idx to ensure pairing
  faith_1 <- faith_1 %>% arrange(example_idx)
  faith_n <- faith_n %>% arrange(example_idx)
  
  # Wilcoxon Signed-Rank Test (paired)
  # Test if faithfulness for appendix n > appendix 1
  # alternative = "less" tests if faith_1 < faith_n (i.e., faith_n > faith_1)
  test_result <- wilcox.test(
    faith_1$faithfulness_beta_mean,
    faith_n$faithfulness_beta_mean,
    paired = TRUE,
    alternative = "less"
  )
  
  list(
    test = test_result,
    faith_1 = faith_1,
    faith_n = faith_n
  )
}

##########################################################
# Evaluate all combinations
##########################################################

hypothesis_failed <- list()

for (dataset in datasets) {
  
  appendices <- dataset_appendices[[dataset]]
  
  # Get appendix 1 (baseline)
  appendix_1 <- appendices[1]
  
  # Get appendices > 1 to compare against baseline
  appendices_n <- appendices[appendices > 1]
  
  for (model in models) {
    
    for (appendix in appendices_n) {
      
      cat(
        "\n=============================================\n"
      )
      
      cat(
        dataset,
        "|",
        model,
        "| comparing appendix 1 vs appendix:",
        appendix,
        "\n"
      )
      
      cat(
        "=============================================\n"
      )
      
      # Reconstruct the atomic baseline from the joint run's atomic_kl_div
      faith_1 <- load_atomic_faithfulness_json(dataset, model, appendix)
      
      # Load adjusted faithfulness from the same joint run
      faith_n <- load_faithfulness_json(dataset, model, appendix)
      
      result <- run_hypothesis_4_test(faith_1, faith_n)
      
      print(result$test)
      
      ######################################################
      # Hypothesis: appendix n should have greater faithfulness than appendix 1
      # (p-value <= 0.05 for Wilcoxon test with alternative = "less")
      ######################################################
      
      p_value <- result$test$p.value
      threshold <- 0.05
      
      if (p_value > threshold) {
        hypothesis_failed[[length(hypothesis_failed) + 1]] <-
          list(
            dataset = dataset,
            model = model,
            appendix_1 = appendix_1,
            appendix_n = appendix,
            p_value = p_value
          )
      }
      
    }
    
  }
  
}

##########################################################
# Summary
##########################################################

cat("\n\n")

if (length(hypothesis_failed) == 0) {
  
  cat("\033[32m")
  cat("All hypothesis tests passed.\n")
  cat("\033[39m")
  
} else {
  
  cat("\033[31m")
  cat("Hypothesis failed for:\n\n")
  
  for (x in hypothesis_failed) {
    cat(
      "- Dataset: ", x$dataset,
      " | Model: ", x$model,
      " | Appendix 1: ", x$appendix_1,
      " | Appendix n: ", x$appendix_n,
      " | p = ", signif(x$p_value, 3),
      "\n",
      sep = ""
    )
  }
  
  cat("\033[39m")
  
}
