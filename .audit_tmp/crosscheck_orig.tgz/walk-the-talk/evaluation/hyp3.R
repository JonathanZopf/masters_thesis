# Hypothesis 3 Checking Script
# Checks if FELICS correction preserves ranking of CE scores

source("faithfulness_loader.R")

library(dplyr)
library(readr)

##########################################################
# Configuration
##########################################################

datasets <- c(
  "bbq",
  "medqa",
  "new_german_credit"
)

models <- c(
  "gpt-oss:120b",
  "mistral-medium-3_5"
)

# For each dataset specify appendices
dataset_appendices <- list(
  medqa = c(1, 4),
  bbq = c(1, 4),
  new_german_credit = c(1,3)
  
)

##########################################################
# Hypothesis test
##########################################################

run_hypothesis_3_test <- function(shapley_ce_estimates) {
  
  # Select the two columns of interest
  data <- shapley_ce_estimates %>%
    select(shapley_kl_div, adjusted_shapley_kl_div) %>%
    na.omit()
  
  # Calculate Spearman's rank correlation
  # Using alternative = "greater" to test for positive correlation
  test_result <- cor.test(
    data$shapley_kl_div,
    data$adjusted_shapley_kl_div,
    method = "spearman",
    alternative = "greater"
  )
  
  list(
    test = test_result,
    rho = test_result$estimate,
    p_value = test_result$p.value
  )
}

##########################################################
# Evaluate all combinations
##########################################################

hypothesis_failed <- list()

for (dataset in datasets) {
  
  appendices <- dataset_appendices[[dataset]]
  
  for (appendix in appendices) {
    
    for (model in models) {
      
      cat(
        "\n=============================================\n"
      )
      
      cat(
        dataset,
        "|",
        model,
        "| appendix:",
        appendix,
        "\n"
      )
      
      cat(
        "=============================================\n"
      )
      
      # Load FELICS shapley_ce_estimates table - will halt on any error
      shapley_ce <- load_faithfulness_table(dataset, model, appendix, "shapley_ce_estimates", "felics")
      
      result <- run_hypothesis_3_test(shapley_ce)
      
      print(result$test)
      
      ######################################################
      # Hypothesis: Strong positive Spearman correlation expected
      # Tight criterion: rho >= 0.9 and p-value <= 0.05
      ######################################################
      
      rho <- result$rho
      p_value <- result$p_value
      threshold_rho <- 0.9
      threshold_p <- 0.05
      
      if (is.na(rho) || rho < threshold_rho || p_value > threshold_p) {
        hypothesis_failed[[length(hypothesis_failed) + 1]] <-
          list(
            dataset = dataset,
            model = model,
            appendix = appendix,
            rho = rho,
            p_value = p_value
          )
      }
      
    }
    
  }
  
}

##########################################################
# Summary
##########################################################

cat("\n\n")

if (length(hypothesis_failed) == 0) {
  
  cat("\033[32m")
  cat("All hypothesis tests passed.\n")
  cat("\033[39m")
  
} else {
  
  cat("\033[31m")
  cat("Hypothesis failed for:\n\n")
  
  for (x in hypothesis_failed) {
    cat(
      "- Dataset: ", x$dataset,
      " | Model: ", x$model,
      " | Appendix: ", x$appendix,
      " | rho = ", round(x$rho, 3),
      " | p = ", signif(x$p_value, 3),
      "\n",
      sep = ""
    )
  }
  
  cat("\033[39m")
  
}
