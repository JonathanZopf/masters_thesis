suppressPackageStartupMessages({
  library(dplyr)
  library(jsonlite)
  library(readr)
})

source("faithfulness_loader.R")
source("hyp1.R")

args <- commandArgs(trailingOnly = TRUE)
if (!length(args)) stop("Provide the thesis data directory")
thesis_data <- args[[1L]]

datasets <- c("bbq", "medqa", "new_german_credit")
models <- c("gpt-oss:120b", "mistral-medium-3_5")
joint_appendix <- c(bbq = 4L, medqa = 4L, new_german_credit = 3L)

display_dataset <- function(x) switch(
  x, bbq = "BBQ", medqa = "MedQA",
  new_german_credit = "New German Credit", x
)
display_model <- function(x) switch(
  x, "gpt-oss:120b" = "GPT-OSS 120B",
  "mistral-medium-3_5" = "Mistral Medium 3.5", x
)
file_stem <- function(dataset, model) paste0(
  dataset, "_",
  switch(model, "gpt-oss:120b" = "gptoss", "mistral-medium-3_5" = "mistral")
)
summary_file_stem <- function(dataset, model) sub(
  "^new_german_credit_", "credit_", file_stem(dataset, model)
)
atomic_json <- function(dataset, model, appendix) {
  path <- file.path(
    felics_base_path, dataset, paste0(model, "_", appendix),
    paste0(model, "_faithfulness_results_atomic_ce.json")
  )
  fromJSON(read_file(path), flatten = TRUE)
}
joint_json <- function(dataset, model, appendix) {
  path <- file.path(
    felics_base_path, dataset, paste0(model, "_", appendix),
    paste0(model, "_faithfulness_results.json")
  )
  fromJSON(read_file(path), flatten = TRUE)
}
question_faithfulness <- function(result, output_name) {
  result$example_level_faithfulness %>%
    transmute(
      example_idx = as.integer(example_idx),
      !!output_name := faithfulness_beta_mean
    )
}

# RQ1 plot inputs and primary/analogous hypothesis results.
rq1_results <- list()
for (dataset in c("bbq", "medqa")) {
  appendix <- joint_appendix[[dataset]]
  for (model in models) {
    ce <- load_faithfulness_table(dataset, model, appendix, "ce_estimates", "felics")
    shapley <- load_faithfulness_table(dataset, model, appendix, "shapley_ce_estimates", "felics")
    adjusted <- joint_json(dataset, model, appendix)
    atomic <- atomic_json(dataset, model, appendix)
    result <- run_hypothesis_test(ce, shapley, adjusted, atomic)
    plot_data <- result$table %>%
      select(example_idx, diff_correlation_strength,
             mean_absolute_ce_diff, faithfulness_diff)
    write_csv(plot_data, file.path(thesis_data, "rq1", paste0(file_stem(dataset, model), ".csv")))
    rq1_results[[length(rq1_results) + 1L]] <- data.frame(
      dataset = display_dataset(dataset), model = display_model(model),
      outcome = "delta_ce",
      r = unname(result$ce_correlation$estimate),
      p = result$ce_correlation$p.value,
      supported = unname(result$ce_correlation$estimate) >= 0.10 &&
        result$ce_correlation$p.value <= 0.10
    )
    rq1_results[[length(rq1_results) + 1L]] <- data.frame(
      dataset = display_dataset(dataset), model = display_model(model),
      outcome = "delta_faithfulness",
      r = unname(result$faithfulness_correlation$estimate),
      p = result$faithfulness_correlation$p.value,
      supported = unname(result$faithfulness_correlation$estimate) >= 0.10 &&
        result$faithfulness_correlation$p.value <= 0.10
    )
  }
}
rq1_results <- bind_rows(rq1_results) %>%
  mutate(r = round(r, 3), p = round(p, 4), supported = tolower(as.character(supported)))
write_csv(rq1_results, file.path(thesis_data, "rq1", "hypothesis_test_results.csv"))

# RQ3 aggregate tests and question-level non-identical rankings.
rq3_results <- list()
for (dataset in datasets) {
  appendix <- joint_appendix[[dataset]]
  for (model in models) {
    shapley <- load_faithfulness_table(dataset, model, appendix, "shapley_ce_estimates", "felics")
    complete <- shapley %>%
      filter(is.finite(shapley_kl_div), is.finite(adjusted_shapley_kl_div))
    aggregate_test <- suppressWarnings(cor.test(
      complete$shapley_kl_div, complete$adjusted_shapley_kl_div,
      method = "spearman", alternative = "greater"
    ))
    rho <- unname(aggregate_test$estimate)
    # cor.test can underflow to a literal zero for these large aggregate
    # samples. Preserve a finite scientific-notation value for LaTeX instead
    # of rendering the misleading expression 0.00 x 10^0.
    p_for_export <- if (aggregate_test$p.value == 0) .Machine$double.xmin else aggregate_test$p.value
    rq3_results[[length(rq3_results) + 1L]] <- data.frame(
      dataset = display_dataset(dataset), model = display_model(model),
      rho = round(rho, 3), p_scientific = p_for_export,
      supported = tolower(as.character(rho >= 0.90 && aggregate_test$p.value <= 0.05))
    )

    exceptions <- complete %>%
      group_by(example_idx) %>%
      group_modify(~ {
        if (nrow(.x) < 3L) return(tibble(rho = NA_real_, p_value = NA_real_))
        test <- suppressWarnings(cor.test(
          .x$shapley_kl_div, .x$adjusted_shapley_kl_div,
          method = "spearman", alternative = "greater", exact = FALSE
        ))
        tibble(rho = unname(test$estimate), p_value = test$p.value)
      }) %>%
      ungroup() %>%
      filter(is.na(rho) | rho < 1 - 1e-12) %>%
      transmute(index = example_idx, rho = round(rho, 3), p_value = round(p_value, 3))
    write_csv(
      exceptions,
      file.path(thesis_data, "rq3", paste0(file_stem(dataset, model), "_imperfect_rows.csv")),
      na = ""
    )
  }
}
write_csv(bind_rows(rq3_results), file.path(thesis_data, "rq3", "hypothesis_test_results.csv"))

# RQ4 plots, primary tests, and summary-plot inputs.
rq4_results <- list()
dataset_summary <- list()
appendix_ce_shift_directory <- file.path(thesis_data, "appendix", "ce_shifts")
dir.create(appendix_ce_shift_directory, recursive = TRUE, showWarnings = FALSE)
for (dataset in datasets) {
  appendix <- joint_appendix[[dataset]]
  for (model in models) {
    atomic <- atomic_json(dataset, model, appendix)
    joint <- joint_json(dataset, model, appendix)
    pairs <- inner_join(
      question_faithfulness(atomic, "atomic_faithfulness"),
      question_faithfulness(joint, "joint_faithfulness"),
      by = "example_idx"
    ) %>% filter(is.finite(atomic_faithfulness), is.finite(joint_faithfulness))
    write_csv(pairs, file.path(thesis_data, "rq4", paste0(file_stem(dataset, model), ".csv")))
    write_csv(
      rename(pairs, interaction_faithfulness = joint_faithfulness),
      file.path(thesis_data, "summary", paste0("question_level_faithfulness_", summary_file_stem(dataset, model), ".csv"))
    )
    ce_shift_pairs <- load_faithfulness_table(
      dataset, model, appendix, "shapley_ce_estimates", "felics"
    ) %>%
      group_by(example_idx) %>%
      summarise(
        atomic_ce = if (all(is.na(atomic_kl_div))) NA_real_ else
          mean(atomic_kl_div, na.rm = TRUE),
        interaction_ce = if (all(is.na(adjusted_shapley_kl_div))) NA_real_ else
          mean(adjusted_shapley_kl_div, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      filter(is.finite(atomic_ce), is.finite(interaction_ce)) %>%
      arrange(example_idx)
    write_csv(
      ce_shift_pairs,
      file.path(appendix_ce_shift_directory, paste0(file_stem(dataset, model), ".csv"))
    )
    differences <- pairs$joint_faithfulness - pairs$atomic_faithfulness
    test <- wilcox.test(
      pairs$atomic_faithfulness, pairs$joint_faithfulness,
      paired = TRUE, alternative = "less"
    )
    rq4_results[[length(rq4_results) + 1L]] <- data.frame(
      dataset = display_dataset(dataset), model = display_model(model),
      n_positive = sum(differences > 0), n_negative = sum(differences < 0),
      n_zero = sum(differences == 0), p = test$p.value,
      supported = tolower(as.character(test$p.value <= 0.05))
    )
    dataset_summary[[length(dataset_summary) + 1L]] <- data.frame(
      panel_id = gsub("_", "-", summary_file_stem(dataset, model)),
      atomic_dataset_faithfulness = atomic$faithfulness_beta_mean,
      joint_dataset_faithfulness = joint$faithfulness_beta_mean
    )
  }
}
rq4_results <- bind_rows(rq4_results) %>% mutate(p = round(p, 4))
write_csv(rq4_results, file.path(thesis_data, "rq4", "hypothesis_test_results.csv"))
write_csv(bind_rows(dataset_summary), file.path(thesis_data, "summary", "dataset_faithfulness_estimates.csv"))

# RQ5 concept-level and posterior summaries.
rq5_dir <- file.path(felics_base_path, "medqa", "rq5_felics")
rq5_models <- c("gpt-oss:120b", "mistral-medium-3.5")
rq5_shapley <- lapply(rq5_models, function(model) {
  read_csv(file.path(rq5_dir, model, paste0(model, "_shapley_ce_estimates.csv")), show_col_types = FALSE)
})
names(rq5_shapley) <- c("gpt", "mistral")
concept_map <- c(
  "The age of the patient" = "Age",
  "The gender of the patient" = "Gender",
  "The patient's eating disorder" = "Eating disorder",
  "The patient's mental status upon arrival" = "Mental status",
  "The patient's reason for the medical visit" = "Reason for visit",
  "The patient's refusal of further treatment" = "Refusal of treatment",
  "The patient's self-perception of weight" = "Self-perception",
  "The patient's vital signs upon arrival" = "Vital signs",
  "The treatment administered by EMS" = "EMS treatment"
)
extract_rq5 <- function(data, prefix) data %>%
  mutate(concept = unname(concept_map[intrv_concepts])) %>%
  transmute(
    concept,
    !!paste0(prefix, "_atomic") := atomic_kl_div,
    !!paste0(prefix, "_joint") := adjusted_shapley_kl_div
  ) %>%
  mutate(!!paste0(prefix, "_delta") := .data[[paste0(prefix, "_joint")]] - .data[[paste0(prefix, "_atomic")]])
rq5_values <- inner_join(extract_rq5(rq5_shapley$gpt, "gpt"),
                         extract_rq5(rq5_shapley$mistral, "mistral"), by = "concept")
old_comparison <- read_csv(file.path(thesis_data, "rq5", "concept_ce_comparison.csv"), show_col_types = FALSE)
comparison <- old_comparison %>%
  select(concept, starts_with("matton_")) %>%
  left_join(rq5_values, by = "concept")
write_csv(comparison, file.path(thesis_data, "rq5", "concept_ce_comparison.csv"))
identity <- comparison %>%
  mutate(concept_id = row_number()) %>%
  select(concept_id, concept, gpt_atomic, gpt_joint, mistral_atomic, mistral_joint)
write_csv(identity, file.path(thesis_data, "rq5", "concept_ce_identity.csv"))

ci_text <- function(result) sprintf(
  "[%.3f; %.3f]", result$faithfulness_beta_ci_lower,
  result$faithfulness_beta_ci_upper
)
rq5_faith_path <- file.path(thesis_data, "rq5", "faithfulness_comparison.csv")
published <- read_csv(rq5_faith_path, show_col_types = FALSE) %>%
  slice_head(n = 3) %>%
  mutate(across(c(atomic_f, atomic_ci, joint_f, joint_ci, delta_f), as.character))
experimental_rows <- lapply(seq_along(rq5_models), function(i) {
  model <- rq5_models[[i]]
  folder <- file.path(rq5_dir, model)
  joint <- fromJSON(read_file(file.path(folder, paste0(model, "_faithfulness_results.json"))), flatten = TRUE)
  atomic <- fromJSON(read_file(file.path(folder, paste0(model, "_faithfulness_results_atomic_ce.json"))), flatten = TRUE)
  data.frame(
    source = "This work", model = display_model(gsub("\\.5$", "_5", model)),
    atomic_f = sprintf("%.3f", atomic$faithfulness_beta_mean), atomic_ci = ci_text(atomic),
    joint_f = sprintf("%.3f", joint$faithfulness_beta_mean), joint_ci = ci_text(joint),
    delta_f = sprintf("%.3f", joint$faithfulness_beta_mean - atomic$faithfulness_beta_mean)
  )
})
write_csv(bind_rows(published, bind_rows(experimental_rows)), rq5_faith_path, na = "--")

cat("Exported refreshed thesis data to ", normalizePath(thesis_data), "\n", sep = "")
