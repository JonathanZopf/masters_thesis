library(dplyr)
library(readr)
library(jsonlite)

##########################################################
# Configuration
##########################################################

datasets <- c("bbq", "medqa")
models <- c("gpt-oss:120b", "mistral-medium-3_5")

# H1 uses only the joint configuration. Its singleton effects
# are already stored in the atomic_kl_div column.
dataset_appendices <- list(
  medqa = 4,
  bbq = 4
)

correlation_threshold <- 0.10
correlation_alpha <- 0.10
faithfulness_alpha <- 0.05

base_path <- file.path("..", "experiment", "faithfulness_results")

##########################################################
# Helpers
##########################################################

load_csv_safe <- function(path) {
  if (!file.exists(path)) {
    stop("File does not exist: ", path)
  }

  tryCatch(
    read_csv(path, show_col_types = FALSE),
    error = function(e) {
      stop(paste("Could not load:", path, "\n", e$message))
    }
  )
}

load_json_safe <- function(path) {
  if (!file.exists(path)) {
    stop("File does not exist: ", path)
  }

  tryCatch(
    fromJSON(path, flatten = TRUE),
    error = function(e) {
      stop(paste("Could not load:", path, "\n", e$message))
    }
  )
}

# Count selected concepts from the treatment bit vector in a
# name such as "0_G0_C2_(101)". This deliberately avoids the
# currently incorrect n_concepts_in_treatment column.
count_treatment_concepts <- function(treatment) {
  treatment_bits <- sub(
    ".*\\(([^()]*)\\)$",
    "\\1",
    treatment
  )

  nchar(gsub("[^1]", "", treatment_bits))
}

run_positive_correlation_test <- function(x, y) {
  complete <- complete.cases(x, y)
  x <- x[complete]
  y <- y[complete]

  if (length(x) < 3 || sd(x) == 0 || sd(y) == 0) {
    return(NULL)
  }

  cor.test(
    x,
    y,
    method = "pearson",
    alternative = "greater"
  )
}

##########################################################
# Hypothesis test
##########################################################

run_hypothesis_test <- function(
    joint_ce,
    joint_shapley_ce,
    adjusted_faithfulness_results,
    atomic_faithfulness_results
) {
  if (
    !identical(
      adjusted_faithfulness_results$faithfulness_ce_column,
      "adjusted_shapley_kl_div"
    )
  ) {
    stop(
      "Adjusted faithfulness JSON was not calculated from ",
      "adjusted_shapley_kl_div."
    )
  }

  if (
    !identical(
      atomic_faithfulness_results$faithfulness_ce_column,
      "atomic_kl_div"
    )
  ) {
    stop(
      "Atomic faithfulness JSON was not calculated from ",
      "atomic_kl_div."
    )
  }

  required_shapley_columns <- c(
    "example_idx",
    "intrv_concepts",
    "atomic_kl_div",
    "adjusted_shapley_kl_div"
  )

  missing_shapley_columns <- setdiff(
    required_shapley_columns,
    names(joint_shapley_ce)
  )

  if (length(missing_shapley_columns) > 0) {
    stop(
      "Missing required Shapley columns: ",
      paste(missing_shapley_columns, collapse = ", ")
    )
  }

  ########################################################
  # Correlation strength from the joint configuration
  ########################################################

  concept_counts <-
    joint_shapley_ce %>%
    count(example_idx, name = "n_concepts")

  joint_strength <-
    joint_ce %>%
    mutate(
      treatment_size = count_treatment_concepts(treatment)
    ) %>%
    group_by(example_idx) %>%
    summarise(
      total_concept_occurrences = sum(treatment_size),
      .groups = "drop"
    ) %>%
    inner_join(concept_counts, by = "example_idx") %>%
    mutate(
      correlation_strength_joint =
        total_concept_occurrences / n_concepts,
      # kappa(x, 1) = 1 analytically.
      diff_correlation_strength =
        abs(correlation_strength_joint - 1)
    )

  ########################################################
  # Question-level CE differences
  ########################################################

  question_ce <-
    joint_shapley_ce %>%
    group_by(example_idx) %>%
    summarise(
      atomic_ce_mean = mean(atomic_kl_div, na.rm = TRUE),
      adjusted_ce_mean =
        mean(adjusted_shapley_kl_div, na.rm = TRUE),
      # Primary measure: increases and decreases in different
      # concepts cannot cancel each other out.
      mean_absolute_ce_diff =
        mean(
          abs(adjusted_shapley_kl_div - atomic_kl_div),
          na.rm = TRUE
        ),
      # Sensitivity measure matching the thesis's original
      # absolute difference of question-level means.
      absolute_ce_mean_diff =
        abs(adjusted_ce_mean - atomic_ce_mean),
      .groups = "drop"
    )

  ########################################################
  # Controlled Bayesian question-level faithfulness
  ########################################################

  adjusted_question_faithfulness <-
    adjusted_faithfulness_results$example_level_faithfulness

  atomic_question_faithfulness <-
    atomic_faithfulness_results$example_level_faithfulness

  required_faithfulness_columns <- c(
    "example_idx",
    "faithfulness_beta_mean"
  )

  if (
    is.null(adjusted_question_faithfulness) ||
    !all(
      required_faithfulness_columns %in%
        names(adjusted_question_faithfulness)
    )
  ) {
    stop(
      "Adjusted faithfulness JSON lacks non-empty ",
      "example_level_faithfulness results."
    )
  }

  if (
    is.null(atomic_question_faithfulness) ||
    !all(
      required_faithfulness_columns %in%
        names(atomic_question_faithfulness)
    )
  ) {
    stop(
      "Atomic faithfulness JSON lacks non-empty ",
      "example_level_faithfulness results."
    )
  }

  question_faithfulness <-
    adjusted_question_faithfulness %>%
    transmute(
      example_idx = as.integer(example_idx),
      adjusted_faithfulness = faithfulness_beta_mean
    ) %>%
    inner_join(
      atomic_question_faithfulness %>%
        transmute(
          example_idx = as.integer(example_idx),
          atomic_faithfulness = faithfulness_beta_mean
        ),
      by = "example_idx"
    ) %>%
    mutate(
      faithfulness_diff =
        abs(adjusted_faithfulness - atomic_faithfulness),
      signed_faithfulness_change =
        adjusted_faithfulness - atomic_faithfulness
    )

  dataset_faithfulness <- list(
    adjusted =
      adjusted_faithfulness_results$faithfulness_beta_mean,
    adjusted_ci_lower =
      adjusted_faithfulness_results$faithfulness_beta_ci_lower,
    adjusted_ci_upper =
      adjusted_faithfulness_results$faithfulness_beta_ci_upper,
    atomic =
      atomic_faithfulness_results$faithfulness_beta_mean,
    atomic_ci_lower =
      atomic_faithfulness_results$faithfulness_beta_ci_lower,
    atomic_ci_upper =
      atomic_faithfulness_results$faithfulness_beta_ci_upper
  )

  dataset_faithfulness$difference <-
    dataset_faithfulness$adjusted -
      dataset_faithfulness$atomic

  ########################################################
  # Final question-level table and tests
  ########################################################

  question_table <-
    joint_strength %>%
    inner_join(question_ce, by = "example_idx") %>%
    left_join(question_faithfulness, by = "example_idx")

  ce_correlation <-
    run_positive_correlation_test(
      question_table$diff_correlation_strength,
      question_table$mean_absolute_ce_diff
    )

  ce_mean_sensitivity_correlation <-
    run_positive_correlation_test(
      question_table$diff_correlation_strength,
      question_table$absolute_ce_mean_diff
    )

  faithfulness_correlation <-
    run_positive_correlation_test(
      question_table$diff_correlation_strength,
      question_table$faithfulness_diff
    )

  faithfulness_pairs <-
    question_table %>%
    filter(
      complete.cases(
        atomic_faithfulness,
        adjusted_faithfulness
      )
    )

  faithfulness_difference_test <- NULL

  if (nrow(faithfulness_pairs) > 0) {
    faithfulness_difference_test <-
      wilcox.test(
        faithfulness_pairs$adjusted_faithfulness,
        faithfulness_pairs$atomic_faithfulness,
        paired = TRUE,
        alternative = "greater",
        exact = FALSE
      )
  }

  list(
    ce_correlation = ce_correlation,
    ce_mean_sensitivity_correlation =
      ce_mean_sensitivity_correlation,
    faithfulness_correlation = faithfulness_correlation,
    faithfulness_difference_test = faithfulness_difference_test,
    dataset_faithfulness = dataset_faithfulness,
    table = question_table,
    n_adjusted_faithfulness_questions =
      nrow(adjusted_question_faithfulness),
    n_atomic_faithfulness_questions =
      nrow(atomic_question_faithfulness)
  )
}

##########################################################
# Evaluate all combinations
##########################################################

hypothesis_failed <- list()

for (dataset in datasets) {
  joint_appendix <- dataset_appendices[[dataset]]

  for (model in models) {
    cat("\n=============================================\n")
    cat(
      dataset,
      "|",
      model,
      "| joint configuration:",
      joint_appendix,
      "\n"
    )
    cat("=============================================\n")

    joint_folder <-
      file.path(
        base_path,
        dataset,
        paste0(model, "_", joint_appendix)
      )

    joint_ce_path <-
      file.path(
        joint_folder,
        paste0(model, "_ce_estimates.csv")
      )

    joint_shapley_path <-
      file.path(
        joint_folder,
        paste0(model, "_shapley_ce_estimates.csv")
      )

    adjusted_faithfulness_path <-
      file.path(
        joint_folder,
        paste0(model, "_faithfulness_results.json")
      )

    atomic_faithfulness_path <-
      file.path(
        joint_folder,
        paste0(
          model,
          "_faithfulness_results_atomic_ce.json"
        )
      )

    loaded <- tryCatch(
      {
        joint_ce <- load_csv_safe(joint_ce_path)
        joint_shapley_ce <- load_csv_safe(joint_shapley_path)
        adjusted_faithfulness_results <-
          load_json_safe(adjusted_faithfulness_path)
        atomic_faithfulness_results <-
          load_json_safe(atomic_faithfulness_path)
        TRUE
      },
      error = function(e) {
        cat("\033[33m")
        cat("Skipping combination because data could not be loaded:\n")
        cat(e$message, "\n")
        cat("\033[39m")
        FALSE
      }
    )

    if (!loaded) {
      next
    }

    result <-
      run_hypothesis_test(
        joint_ce,
        joint_shapley_ce,
        adjusted_faithfulness_results,
        atomic_faithfulness_results
      )

    cat(
      "\nPrimary H1 test: correlation strength vs ",
      "mean absolute concept-level CE change\n",
      sep = ""
    )

    if (is.null(result$ce_correlation)) {
      cat("Test unavailable because of insufficient variance.\n")
    } else {
      print(result$ce_correlation)
    }

    cat(
      "\nSensitivity test: correlation strength vs ",
      "absolute difference of question-level CE means\n",
      sep = ""
    )

    if (is.null(result$ce_mean_sensitivity_correlation)) {
      cat("Test unavailable because of insufficient variance.\n")
    } else {
      print(result$ce_mean_sensitivity_correlation)
    }

    cat(
      "\nAnalogous H1 test: correlation strength vs ",
      "absolute question-level faithfulness change\n",
      sep = ""
    )

    if (is.null(result$faithfulness_correlation)) {
      cat("Test unavailable because of insufficient variance.\n")
    } else {
      print(result$faithfulness_correlation)
    }

    cat(
      "\nPaired question-level faithfulness test ",
      "(adjusted > atomic)\n",
      sep = ""
    )

    if (is.null(result$faithfulness_difference_test)) {
      cat("Test unavailable because no valid pairs remain.\n")
    } else {
      print(result$faithfulness_difference_test)
    }

    dataset_faithfulness <- result$dataset_faithfulness

    cat(
      "\nDataset-level Bayesian faithfulness:\n",
      "- Atomic CE: ",
      round(dataset_faithfulness$atomic, 4),
      " (90% CI [",
      round(dataset_faithfulness$atomic_ci_lower, 4),
      ", ",
      round(dataset_faithfulness$atomic_ci_upper, 4),
      "])\n",
      "- Adjusted Shapley CE: ",
      round(dataset_faithfulness$adjusted, 4),
      " (90% CI [",
      round(dataset_faithfulness$adjusted_ci_lower, 4),
      ", ",
      round(dataset_faithfulness$adjusted_ci_upper, 4),
      "])\n",
      "- Adjusted minus atomic: ",
      round(dataset_faithfulness$difference, 4),
      "\n",
      sep = ""
    )

    cat(
      "Questions analyzed:",
      nrow(result$table),
      "| Questions with valid faithfulness:",
      sum(
        complete.cases(
          result$table$atomic_faithfulness,
          result$table$adjusted_faithfulness
        )
      ),
      "| Bayesian questions in adjusted/atomic JSON:",
      result$n_adjusted_faithfulness_questions,
      "/",
      result$n_atomic_faithfulness_questions,
      "\n"
    )

    ce_result <- result$ce_correlation

    if (is.null(ce_result)) {
      hypothesis_failed[[length(hypothesis_failed) + 1]] <-
        list(
          dataset = dataset,
          model = model,
          joint = joint_appendix,
          correlation = NA_real_,
          p_value = NA_real_,
          reason = "test unavailable"
        )
    } else {
      estimate <- unname(ce_result$estimate)
      p_value <- ce_result$p.value

      if (
        is.na(estimate) ||
        estimate < correlation_threshold ||
        p_value > correlation_alpha
      ) {
        hypothesis_failed[[length(hypothesis_failed) + 1]] <-
          list(
            dataset = dataset,
            model = model,
            joint = joint_appendix,
            correlation = estimate,
            p_value = p_value,
            reason = "criterion not met"
          )
      }
    }
  }
}

##########################################################
# Summary
##########################################################

cat("\n\n")

if (length(hypothesis_failed) == 0) {
  cat("\033[32m")
  cat("All primary Hypothesis 1 tests passed.\n")
  cat("\033[39m")
} else {
  cat("\033[31m")
  cat("Primary Hypothesis 1 test failed for:\n\n")

  for (x in hypothesis_failed) {
    cat(
      "- Dataset: ", x$dataset,
      " | Model: ", x$model,
      " | Joint: ", x$joint,
      " | r = ", round(x$correlation, 3),
      " | p = ", signif(x$p_value, 3),
      " | ", x$reason,
      "\n",
      sep = ""
    )
  }

  cat("\033[39m")
}

cat(
  "\nDecision criteria for the primary H1 test: r >= ",
  correlation_threshold,
  " and p <= ",
  correlation_alpha,
  ".\n",
  sep = ""
)

cat(
  "The paired faithfulness test is reported separately with alpha = ",
  faithfulness_alpha,
  ".\n",
  sep = ""
)
